Blocks.mechanicalPump.pumpAmount = 0.12
Blocks.impulsePump.pumpAmount = 120 / 9 / 60
Blocks.laserDrill.drillTime = 270
Blocks.laserDrill.hardnessDrillMultiplier = 45
Blocks.blastDrill.drillTime = 255
Blocks.blastDrill.hardnessDrillMultiplier = 45

UnitTypes.alpha.coreUnitDock = true
UnitTypes.beta.coreUnitDock = true
UnitTypes.gamma.coreUnitDock = true
